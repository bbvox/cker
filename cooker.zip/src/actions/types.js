export const START_FETCH = "START_FETCH";
export const FETCH_POSTS = "FETCH_POSTS";
export const START_POST = "START_POST";
export const NEW_POST = "NEW_POST";
export const CLICK_MENU = "CLICK_MENU";
