import React from "react";

const Footer = props => {
  return <footer> FOOTER </footer>;
};

export default Footer;
