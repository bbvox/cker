import Header from "./Header";
import Slider from "./slider";

import Home from "./Home";
import Multi from "./Multi";
import Single from "./Single";
import Footer from "./Footer";

export {
  Header,
  Slider,
  Home,
  Multi,
  Single,
  Footer
}